/*
 * BT_Robot.c
 *
 * Created: 3/24/2016 3:20:17 PM
 *  Author: rkasera
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000UL
#include <util/delay.h>

#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

void SetBit(char);
void ResetBit(char);

void BlueLed();
void TestFun();
void reset();

char buffer[100];
volatile int ind = 0;
char verified = 0;

void uart_transmit (unsigned char data);
void send();
void Robot(char);

ISR(USART_RXC_vect)
{
	char ReceivedByte = 'a';
	ReceivedByte = UDR; // Fetch the received byte value into the variable "ByteReceived"
	
	if(verified == 0)
	{
		buffer[ind] = ReceivedByte;
		ind++;
		if(ind >= 4)
		{
			cli();
			//if(buffer[0] == 's' && buffer[1] == 'u' && buffer[2] == 'c' && buffer[3] == 'c' && buffer[4] == 'e' && buffer[5] == 's' && buffer[6] == 's')
			if(buffer[0] == '5' && buffer[1] == '4' && buffer[2] == '3' && buffer[3] == '2' )
			{
				verified = 1;
				BlueLed();
				_delay_ms(1000);
				sei();
				ind = 0;
			}
			else
			{
				reset();
			}
		}
	}
	else{
		    Robot(ReceivedByte);
	}
	//UDR = ReceivedByte; // Echo back the received byte back to the computer
}



int main (void)
{
	DDRC = 0xFF;
    PORTC = 0x3F;
	_delay_ms(400);
	PORTC = 0x0F;
	_delay_ms(400);
	PORTC = 0x3F;
	_delay_ms(400);
	PORTC = 0x0F;
	_delay_ms(400);
	PORTC = 0x3F;
	_delay_ms(400);
	PORTC = 0x0F;
	_delay_ms(400);
	PORTC = 0x3F;
		
	UCSRB = (1 << RXEN) | (1 << TXEN);   // Turn on the transmission and reception circuitry
	UCSRC = (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1); // Use 8-bit character sizes

	UBRRH = (BAUD_PRESCALE >> 8); // Load upper 8-bits of the baud rate value into the high byte of the UBRR register
	UBRRL = BAUD_PRESCALE; // Load lower 8-bits of the baud rate value into the low byte of the UBRR register

	UCSRB |= (1 << RXCIE); // Enable the USART Recieve Complete interrupt (USART_RXC)
	sei(); // Enable the Global Interrupt Enable flag so that interrupts can be processed
    
	//send();
	//PORTC = 0x1F;
	
	
	
	for (;;) // Loop forever
	{
		// Do nothing - echoing is handled by the ISR instead of in the main loop
	}
}

// function to send data - NOT REQUIRED FOR THIS PROGRAM IMPLEMENTATION
void uart_transmit (unsigned char data)
{
	while (!( UCSRA & (1<<UDRE)));            // wait while register is free
	UDR = data;                             // load data in the register
}

void Robot(char cmd)
{
	if(cmd == 'A' || cmd == 'B')
	{
	    if(cmd == 'A')
		    SetBit(1);
        else		
		    ResetBit(1);
	}
	else if(cmd == 'C' || cmd == 'D')
	{
		if(cmd == 'C')
		    SetBit(2);
        else		
		    ResetBit(2);
	}
	else if(cmd == 'E' || cmd == 'F')
	{
		if(cmd == 'E')
		    SetBit(3);
        else		
		    ResetBit(3);
	}
	else if(cmd == 'G' || cmd == 'H')
	{
	    if(cmd == 'G')
		    SetBit(4);
        else		
		    ResetBit(4);
	}
		
}

void send()
{
	uart_transmit('A');
	_delay_ms(10);
	uart_transmit('T');
	_delay_ms(10);
	uart_transmit(0x0D);
	_delay_ms(10);
	uart_transmit(0x0A);
	_delay_ms(1000);
}

void BlueLed()
{
ResetBit(5);
SetBit(6);
_delay_ms(400);
SetBit(5);
ResetBit(6);
_delay_ms(400);
ResetBit(5);
SetBit(6);
_delay_ms(400);
SetBit(5);
ResetBit(6);
_delay_ms(400);
SetBit(5);
SetBit(6);
}


void reset()
{
	while(1)
	{
		SetBit(5);
		SetBit(6);
		_delay_ms(400);
		ResetBit(5);
		ResetBit(6);
		_delay_ms(400);
	}
	
}

void SetBit(char b)
{
	PORTC = PORTC | (1<<(b-1));
}
void ResetBit(char b)
{	
	PORTC = PORTC & ~(1<<(b-1));   
}